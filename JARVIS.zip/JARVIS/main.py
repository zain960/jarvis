import os
import eel

eel.init("frontend")

# Corrected URL to match Eel's serving path
os.system('start msedge.exe --app="http://127.0.0.1:3000/frontend/index.html"')

# Start Eel
eel.start('index.html', mode=None, host='localhost', port=3000, block=True)
